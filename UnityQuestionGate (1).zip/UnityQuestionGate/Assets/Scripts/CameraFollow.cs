using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float smooth = 8f;
    public float yOffset = 2f;

    void LateUpdate()
    {
        if (!target) return;
        Vector3 goal = new Vector3(target.position.x, Mathf.Max(target.position.y + yOffset, 2f), -10f);
        transform.position = Vector3.Lerp(transform.position, goal, smooth * Time.unscaledDeltaTime);
    }
}
