using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class FinishTrigger : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player")) GameManager.Instance.TryFinish();
    }
}
