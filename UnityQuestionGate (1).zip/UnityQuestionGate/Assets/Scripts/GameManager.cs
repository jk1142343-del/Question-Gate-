using UnityEngine;
using TMPro;

/// <summary>Tracks progress, resets everything on a wrong answer, handles completion.</summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public PlayerController player;
    public Transform startPoint;
    public QuestionGate[] gates;
    public GameObject completionPanel;
    public TMP_Text completionText;
    public TMP_Text hudText;

    int opened, attempt = 1;

    void Awake()
    {
        Instance = this;
        Time.timeScale = 1f;
    }

    void Start()
    {
        if (completionPanel) completionPanel.SetActive(false);
        UpdateHud();
    }

    public void OnGateOpened()
    {
        opened++;
        UpdateHud();
    }

    /// <summary>Wrong answer (or falling off the map): back to start, ALL gates locked again.</summary>
    public void RestartFromStart()
    {
        attempt++;
        ResetAll();
    }

    public void RestartGame()
    {
        attempt = 1;
        if (completionPanel) completionPanel.SetActive(false);
        ResetAll();
    }

    void ResetAll()
    {
        Time.timeScale = 1f;
        opened = 0;
        foreach (var g in gates) g.ResetGate();
        player.ResetTo(startPoint.position);
        UpdateHud();
    }

    public void TryFinish()
    {
        if (opened < gates.Length) return;   // all gates must be solved
        if (completionText) completionText.text = $"Level Complete!\nAll {gates.Length} questions answered correctly.\nAttempts: {attempt}";
        completionPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    void UpdateHud()
    {
        if (hudText) hudText.text = $"Gates opened: {opened} / {gates.Length}    Attempt: {attempt}";
    }
}
