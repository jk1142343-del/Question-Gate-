using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

/// <summary>Left/right movement + jump. Works with the old and the new Input System.</summary>
[RequireComponent(typeof(Rigidbody2D), typeof(BoxCollider2D))]
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 6f;
    public float jumpVelocity = 12f;
    public float gravityScale = 3f;
    public float fallLimitY = -10f;   // falling below this restarts the run

    Rigidbody2D rb;
    BoxCollider2D col;
    bool jumpQueued;

    Vector2 Vel
    {
#if UNITY_6000_0_OR_NEWER
        get => rb.linearVelocity; set => rb.linearVelocity = value;
#else
        get => rb.velocity; set => rb.velocity = value;
#endif
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<BoxCollider2D>();
        rb.gravityScale = gravityScale;
        rb.freezeRotation = true;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        col.sharedMaterial = new PhysicsMaterial2D("NoFriction") { friction = 0f, bounciness = 0f };
    }

    void Update()
    {
        if (Time.timeScale == 0f) { jumpQueued = false; return; }   // paused while a question is open
        if (JumpPressed()) jumpQueued = true;
        if (transform.position.y < fallLimitY && GameManager.Instance != null)
            GameManager.Instance.RestartFromStart();
    }

    void FixedUpdate()
    {
        Vector2 v = Vel;
        v.x = Horizontal() * moveSpeed;
        if (jumpQueued && IsGrounded()) v.y = jumpVelocity;
        jumpQueued = false;
        Vel = v;
    }

    bool IsGrounded()
    {
        Bounds b = col.bounds;
        Vector2 c = new Vector2(b.center.x, b.min.y - 0.05f);
        foreach (var h in Physics2D.OverlapBoxAll(c, new Vector2(b.size.x * 0.9f, 0.1f), 0f))
            if (h != col && !h.isTrigger) return true;
        return false;
    }

    public void ResetTo(Vector3 pos)
    {
        Vel = Vector2.zero;
        rb.position = pos;
        transform.position = pos;
        jumpQueued = false;
    }

    float Horizontal()
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        var k = Keyboard.current; if (k == null) return 0f;
        float h = 0f;
        if (k.leftArrowKey.isPressed || k.aKey.isPressed) h -= 1f;
        if (k.rightArrowKey.isPressed || k.dKey.isPressed) h += 1f;
        return h;
#else
        return Input.GetAxisRaw("Horizontal");
#endif
    }

    bool JumpPressed()
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        var k = Keyboard.current; if (k == null) return false;
        return k.spaceKey.wasPressedThisFrame || k.upArrowKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame;
#else
        return Input.GetButtonDown("Jump") || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
#endif
    }
}
