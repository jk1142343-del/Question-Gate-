using System;
using UnityEngine;

/// <summary>One MCQ. Each gate owns its own instance, so gates never share logic or answers.</summary>
[Serializable]
public class QuestionData
{
    [TextArea(2, 4)] public string context;   // short educational statement / scenario
    [TextArea(2, 4)] public string question;  // the actual question
    public string[] options = new string[4];  // exactly 4 answers
    [Range(0, 3)] public int correctIndex;    // 0 = A, 1 = B, 2 = C, 3 = D
}
