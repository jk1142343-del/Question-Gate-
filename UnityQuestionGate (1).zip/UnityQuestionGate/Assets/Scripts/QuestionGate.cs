using System.Collections;
using UnityEngine;

/// <summary>
/// A solid barrier holding ITS OWN question. Touching it opens the MCQ panel.
/// Open() unlocks it (collider off + lowers); ResetGate() locks it again.
/// </summary>
[RequireComponent(typeof(BoxCollider2D), typeof(SpriteRenderer))]
public class QuestionGate : MonoBehaviour
{
    public int gateNumber = 1;
    public QuestionData questionData;
    public Color lockedColor = new Color(0.8f, 0.2f, 0.2f);
    public Color openColor = new Color(0.2f, 0.7f, 0.3f);

    public bool IsOpen { get; private set; }

    BoxCollider2D col;
    SpriteRenderer sr;
    Vector3 startPos, startScale;
    float startHeight;
    Coroutine anim;

    void Awake()
    {
        col = GetComponent<BoxCollider2D>();
        sr = GetComponent<SpriteRenderer>();
        startPos = transform.position;
        startScale = transform.localScale;
        startHeight = sr.bounds.size.y;
        sr.color = lockedColor;
    }

    void OnCollisionEnter2D(Collision2D c)
    {
        if (IsOpen || !c.collider.CompareTag("Player")) return;
        QuestionUIManager.Instance.ShowQuestion(this);
    }

    public void Open()
    {
        IsOpen = true;
        col.enabled = false;
        sr.color = openColor;
        anim = StartCoroutine(Lower());
    }

    IEnumerator Lower()
    {
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / 0.6f;
            float k = Mathf.Clamp01(t);
            transform.localScale = new Vector3(startScale.x, startScale.y * (1f - k), startScale.z);
            transform.position = new Vector3(startPos.x, startPos.y - startHeight * k * 0.5f, startPos.z);
            yield return null;
        }
    }

    public void ResetGate()
    {
        if (anim != null) StopCoroutine(anim);
        IsOpen = false;
        col.enabled = true;
        transform.position = startPos;
        transform.localScale = startScale;
        sr.color = lockedColor;
    }
}
