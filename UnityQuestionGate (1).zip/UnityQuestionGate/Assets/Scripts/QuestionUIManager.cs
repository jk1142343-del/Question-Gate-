using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>Shows the MCQ panel, detects correct / wrong answers, tells GameManager what to do.</summary>
public class QuestionUIManager : MonoBehaviour
{
    public static QuestionUIManager Instance;

    public GameObject panel;
    public TMP_Text titleText, contextText, questionText, feedbackText;
    public Button[] optionButtons = new Button[4];
    public TMP_Text[] optionLabels = new TMP_Text[4];
    public float feedbackDelay = 1.5f;

    static readonly Color Green = new Color(0.2f, 0.65f, 0.3f);
    static readonly Color Red = new Color(0.8f, 0.25f, 0.25f);

    QuestionGate current;
    bool busy;

    void Awake()
    {
        Instance = this;
        panel.SetActive(false);
    }

    public void ShowQuestion(QuestionGate gate)
    {
        if (panel.activeSelf) return;
        current = gate;
        busy = false;
        QuestionData d = gate.questionData;

        titleText.text = $"Gate {gate.gateNumber}";
        contextText.text = d.context;
        questionText.text = d.question;
        feedbackText.text = "";

        for (int i = 0; i < optionButtons.Length; i++)
        {
            int idx = i;
            optionLabels[i].text = $"{(char)('A' + i)}.  {d.options[i]}";
            optionButtons[i].image.color = new Color(0.2f, 0.3f, 0.5f);
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => OnSelect(idx));
        }

        panel.SetActive(true);
        Time.timeScale = 0f;      // freeze the game while the question is open
    }

    void OnSelect(int index)
    {
        if (busy) return;
        busy = true;
        StartCoroutine(Resolve(index));
    }

    IEnumerator Resolve(int index)
    {
        QuestionData d = current.questionData;
        bool correct = index == d.correctIndex;

        optionButtons[index].image.color = correct ? Green : Red;
        if (!correct) optionButtons[d.correctIndex].image.color = Green;
        feedbackText.color = correct ? Green : Red;
        feedbackText.text = correct ? "Correct! The gate is opening." : "Wrong answer! Returning to the start...";

        yield return new WaitForSecondsRealtime(feedbackDelay);

        panel.SetActive(false);
        Time.timeScale = 1f;

        if (correct) { current.Open(); GameManager.Instance.OnGateOpened(); }
        else GameManager.Instance.RestartFromStart();
        current = null;
    }
}
