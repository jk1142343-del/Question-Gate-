# Question Gate Runner – Unity (C#)

2D platformer: run and jump, reach a gate, answer an MCQ. Correct = gate opens. Wrong = back to start, all gates lock again.
Topic used: Programming Fundamentals (replace with your assigned topic).

## Setup (about 3 minutes)
1. Unity 2021.3 LTS or newer (Unity 6 also works). Create a new **2D** project.
2. Copy the `Assets/Scripts` folder from this package into your project's `Assets` folder.
3. If prompted, click **Import TMP Essentials** (or Window > TextMeshPro > Import TMP Essential Resources).
4. Menu: **Tools > Question Gate > Build Prototype Scene**. This builds and saves `Assets/Scenes/QuestionGateGame.unity` (player, ground, platforms, 5 gates, finish flag, UI, managers – all wired).
5. Press **Play**.

Controls: A/D or Left/Right = move, Space/W/Up = jump. Click an answer with the mouse.

## Editing the questions
Open `Assets/Scripts/Editor/QuestionGateSceneBuilder.cs` -> `Questions()`, change the text, then re-run the menu item.
Or select any `Gate_N` in the scene and edit its `Question Data` in the Inspector (context, question, 4 options, correct index 0-3).

## Scripts
| Script | Role |
|---|---|
| PlayerController | Movement, jump, ground check, reset to start |
| QuestionGate | Solid gate with its own QuestionData; opens MCQ on touch; Open()/ResetGate() |
| QuestionData | Serializable question: context, question, 4 options, correct index |
| QuestionUIManager | Shows panel, 4 buttons, detects correct/wrong, colours answers |
| GameManager | Progress, restart on wrong answer (all gates re-lock), completion screen |
| FinishTrigger | Flag at the end; completes the level when all gates are open |
| CameraFollow | Side-scrolling camera |

## Requirement checklist
- Movement + jump: PlayerController
- 5 gates, unique questions: QuestionGate.questionData (independent per gate)
- Touch triggers MCQ panel with statement + 4 options: OnCollisionEnter2D -> QuestionUIManager.ShowQuestion
- Correct: panel closes, gate lowers and unlocks, play continues
- Wrong: correct answer flashes, player returns to start, every gate re-locks (GameManager.RestartFromStart)
- Completion: reach the flag after opening all 5 gates

## Building an executable
File > Build Settings > add the open scene > choose platform > Build.
